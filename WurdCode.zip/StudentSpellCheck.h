#ifndef STUDENTSPELLCHECK_H_
#define STUDENTSPELLCHECK_H_

#include "SpellCheck.h"

#include <string>
#include <vector>

const int ALPHABET_SIZE = 27;

class StudentSpellCheck : public SpellCheck {
public:
	StudentSpellCheck();
	virtual ~StudentSpellCheck();
	bool load(std::string dict_file);
	bool spellCheck(std::string word, int maxSuggestions, std::vector<std::string>& suggestions);
	void spellCheckLine(const std::string& line, std::vector<Position>& problems);

private:
	struct Node
	{
		Node();
		Node* chars[ALPHABET_SIZE];
		bool isLeafNode;
	};
	Node* root;
	void addToTree(std::string s);
	std::string removeBadChars(std::string s);
	bool replaceAndCheck(std::string& s, int index, std::string t);
	bool find(std::string& s);
	void deleteTrie(Node* p);
};

#endif  // STUDENTSPELLCHECK_H_