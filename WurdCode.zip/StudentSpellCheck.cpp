#include "StudentSpellCheck.h"
#include <string>
#include <vector>

#include <iostream>
#include <fstream>
using namespace std;

StudentSpellCheck::StudentSpellCheck()
{
	root = new Node;
}

SpellCheck* createSpellCheck()
{
	return new StudentSpellCheck;
}

StudentSpellCheck::~StudentSpellCheck()
{
	deleteTrie(root);	// delete the trie
}


// Delete every node in the trie with post-order recursion (time complexity: O(N))
// Time Complexity: O(N)
void StudentSpellCheck::deleteTrie(StudentSpellCheck::Node* p)
{
	if (p == nullptr)
		return;
	for (int i = 0; i < ALPHABET_SIZE; i++)
	{
		deleteTrie(p->chars[i]);
	}
	delete p;
}

// Constructor for a Trie Node
StudentSpellCheck::Node::Node()
{
	isLeafNode = false;
	for (int i = 0; i < ALPHABET_SIZE; i++)
	{
		chars[i] = nullptr;	// each of the next letters starts out as nullptr
	}
}

// Time Complexity: O(N)
bool StudentSpellCheck::load(std::string dictionaryFile)
{
	ifstream f(dictionaryFile);
	if (!f)
		return false;
	deleteTrie(root);
	root = new Node;
	string temp;
	while (getline(f, temp))
	{
		addToTree(temp); // add it to the tree if not already present
	}
	return true;
}

// Strip all non letter non apostrophe characters
// Time Complexity: O(S) where S is the size of the string
string StudentSpellCheck::removeBadChars(string s)
{
	string temp;
	for (size_t i = 0; i < s.size(); i++)
	{
		if (isalpha(s.at(i)) || s.at(i) == '\'')
			temp += tolower(s.at(i));
	}
	return temp;
}

// Add a node to the trie
// Time Complexity: O(S) where S is the size of the string
void StudentSpellCheck::addToTree(string s)
{
	s = removeBadChars(s);	// remove any chars that aren't ' or a letter
	Node* p = root;
	for (size_t i = 0; i < s.size(); i++)
	{
		char ch = s.at(i);
		int index = ch - 'a';
		if (ch == '\'')
			index = 26;
		if (p->chars[index] == nullptr)	// if there isn't word with ch as its next character
		{
			p->chars[index] = new Node;	// allocate a new node representing that letter
		}
		p = p->chars[index]; // increment p to the next node (character) in the word
	}
	p->isLeafNode = true;	// the last character of the word represents a leaf node
}

// Time Complexity: O(S) where S is the size of the string
bool StudentSpellCheck::find(string& s)
{
	s = removeBadChars(s);
	Node* p = root;
	for (size_t i = 0; i < s.size(); i++)
	{
		char ch = s.at(i);
		int index = ch - 'a';
		if (ch == '\'')
			index = 26;
		if (index >= 27 || index < 0)	// character is out of bounds (not a valid letter)
			return false;
		if (p->chars[index] == nullptr)
			return false;
		p = p->chars[index];
	}
	return (p != nullptr && p->isLeafNode);	// all words end with leaf nodes
}

// Time Complexity: O(S)
bool StudentSpellCheck::replaceAndCheck(string& s, int index, string t)
{
	s.replace(index, 1, t);	// replace the char at index with string t
	return find(s);
}

// Time Complexity: O(oldS + L^2 + maxSuggestions)
bool StudentSpellCheck::spellCheck(std::string word, int max_suggestions, std::vector<std::string>& suggestions)
{
	if (find(word))	// the word is already in the dictionary
		return true;
	suggestions.clear();	// clear the suggestions vector
	int count = 0;
	string temp;
	string t;
	int size = word.size();
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < ALPHABET_SIZE - 1 && count < max_suggestions; j++)
		{
			temp = word;
			t = "";
			t += ('a' + j);
			if (replaceAndCheck(temp, i, t))  // if this word is in the dictionary, add it to suggestions
			{
				count++;	// keep track of count to make sure it doesn't go over max_suggestions
				suggestions.push_back(temp);
			}
		}
		if (count >= max_suggestions)
			break;
		t = "\'";
		temp = word;
		if (replaceAndCheck(temp, i, t))	// replace with ' and see if it makes a word
		{
			count++;
			suggestions.push_back(temp);
		}
	}
	return false;
}

// Time Complexity: O(oldP + S + W * L)
void StudentSpellCheck::spellCheckLine(const std::string& line, std::vector<SpellCheck::Position>& problems)
{
	int i = 0;
	int size = line.size();
	int start, end;

	problems.clear();
	string res;
	while (i < size)
	{
		start = i;
		while (i < size && (isalpha(line.at(i)) || line.at(i) == '\''))	// go through first word
		{
			i++;
		}
		end = i - 1;
		string temp = line.substr(start, 1.0 * end - start + 1);
		if (!find(temp))   // if that word isn't in the dictionary, add it to the problems vector
		{				
			Position p;
			p.start = start;
			p.end = end;
			problems.push_back(p);
		}
		i++;
	}
}