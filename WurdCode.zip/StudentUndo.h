#ifndef STUDENTUNDO_H_
#define STUDENTUNDO_H_

#include <stack>
#include "Undo.h"

class StudentUndo : public Undo {
public:

	~StudentUndo();
	void submit(Action action, int row, int col, char ch = 0);
	Action get(int& row, int& col, int& count, std::string& text);
	void clear();

private:
	struct data
	{
		data(const Action a, int r, int c, std::string s);
		Action action;
		int row;
		int col;
		std::string str;
	};
	std::stack<data*> dataStack;
};

#endif // STUDENTUNDO_H_
