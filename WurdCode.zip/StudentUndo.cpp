#include "StudentUndo.h"

Undo* createUndo()
{
	return new StudentUndo;
}

StudentUndo::~StudentUndo()
{
	clear();	// remove all undo objects from the stack
}

// Constructor for the data struct
StudentUndo::data::data(const Action a, int r, int c, std::string s)
	: action(a), row(r), col(c), str(s)
{
}

// Time Complexity: O(1) on average, sometimes O(current line length)
void StudentUndo::submit(const Action action, int row, int col, char ch) 
{
	std::string s = "";
	switch (action)
	{
	case INSERT:
		s += ch;
		if (!dataStack.empty() && action == dataStack.top()->action)	// same action
		{
			if (dataStack.top()->col == col || dataStack.top()->col == col - dataStack.top()->str.size())
			{
				if (dataStack.top()->row == row)	// batching
				{
					dataStack.top()->str.append(s);
					break;
				}
			}
		}
		dataStack.push(new data(action, row, col, s));
		break;
	case DELETE:
		s += ch;
		if (!dataStack.empty() && action == dataStack.top()->action)
		{
			// if it's backspace, add it to the beginning; if it's delete add it to the end
			if (dataStack.top()->col == col && dataStack.top()->row == row)
			{
				dataStack.top()->str.append(s);
				break;
			}
			if (dataStack.top()->col == col + 1	&& dataStack.top()->row == row)
			{
				dataStack.top()->col--;
				dataStack.top()->str.insert(0, s);
				break;
			}
		}
	    // previous action wasn't deleting a character
		dataStack.push(new data(action, row, col, s));
		break;
	case JOIN:
	case SPLIT:
		dataStack.push(new data(action, row, col, s));
		break;
	case ERROR:
		return;
	}
}

// Time Complexity: O(1) on average, sometimes O(length of deleted characters)
StudentUndo::Action StudentUndo::get(int& row, int& col, int& count, std::string& text) 
{
	if (dataStack.empty())
		return Action::ERROR;
	switch (dataStack.top()->action)
	{
	case INSERT:
		count = dataStack.top()->str.size(); // set count to the size of the string to be inserted
		col = dataStack.top()->col - 1;	// characters should be deleted starting from the stack's col - 1
		row = dataStack.top()->row;	// characters should be deleted from the stack's row
		text = "";
		delete dataStack.top();	// prevent memory leak
		dataStack.pop();	// pop the top item off the stack
		return Action::DELETE;
	case DELETE:
		count = 1;
		col = dataStack.top()->col;
		row = dataStack.top()->row;
		text = dataStack.top()->str;
		delete dataStack.top();  // prevent memory leak
		dataStack.pop();
		return Action::INSERT;
	case SPLIT:
		row = dataStack.top()->row;
		col = dataStack.top()->col;
		count = 1;
		text = "";
		delete dataStack.top();  // prevent memory leak
		dataStack.pop();
		return Action::JOIN;
	case JOIN:
		row = dataStack.top()->row;	// might delete these two rows
		col = dataStack.top()->col;
		count = 1;
		text = "";
		delete dataStack.top();   // prevent memory leak
		dataStack.pop();
		return Action::SPLIT;
	default:
		return Action::ERROR;
	}
}

// Time Complexity: O(N)
void StudentUndo::clear() 
{
	while (!dataStack.empty())
	{
		delete dataStack.top();
		dataStack.pop();
	}
}
