#include "StudentTextEditor.h"
#include "Undo.h" 
#include <string>
#include <vector>
#include <iostream>
#include <fstream>

using namespace std;

TextEditor* createTextEditor(Undo* un)
{
	return new StudentTextEditor(un);
}

// Time Complexity: O(1)
StudentTextEditor::StudentTextEditor(Undo* undo)
	: TextEditor(undo), m_row(0), m_col(0)
{
	stringList.push_back("");	// start list with one item (the empty string)
	list_it = stringList.begin();
}

StudentTextEditor::~StudentTextEditor()
{
}

// Time Complexity: O(M + N + U)
bool StudentTextEditor::load(std::string file)
{
	ifstream f(file);
	if (!f)			// error reading the file
		return false;

	reset();		// get rid of any data currently showing

	// getline returns infile; the while tests its success/failure state
	list<string>::iterator it = stringList.begin();
	while (getline(f, *it))
	{
		stringList.push_back("");
		it++;
	}
	m_row = 0;
	m_col = 0;
	list_it = stringList.begin();	// list_it points to the current line
	return true;
}

// Time Complexity: O(M)
bool StudentTextEditor::save(std::string file)
{
	ofstream outfile(file);
	if (!outfile)	// error writing the file
		return false;
	list<string>::iterator it = stringList.begin();
	int nRows = stringList.size();
	for (int i = 0; i < nRows; i++)
	{
		outfile << *it << '\n';		// write each string in the list to the file
		it++;
	}
	return true;
}

// Time Complexity: O(N + U)
void StudentTextEditor::reset()
{
	list<string>::iterator it = stringList.begin();
	while (it != stringList.end())
	{
		it = stringList.erase(it);	// erase every line
	}
	stringList.push_back("");	// document is now just one line
	m_row = 0;	// cursor goes back to top
	m_col = 0;
	list_it = stringList.begin();
	getUndo()->clear();	// clear the undo stack
}

// Helper function
int StudentTextEditor::min(int n1, int n2) const 
{
	if (n1 <= n2)
		return n1;
	return n2;
}

// Time Complexity: O(1)
void StudentTextEditor::move(Dir dir)
{
	switch (dir)
	{
	case LEFT:
		if (m_col > 0)		// normally, just decrement the column
			m_col--;
		else if (m_col == 0 && m_row > 0)	// otherwise, go up to previous line if it exists
		{
			m_row--;
			list_it--;
			m_col = list_it->size();
		}
		break;
	case RIGHT:
		if (m_col < list_it->size()) 	// normally, just increment the column
			m_col++;
		else if (m_row < stringList.size() - 1)	// otherwise, go down to next line if it exists
		{
			m_row++;
			list_it++;
			m_col = 0;
		}
		break;
	case DOWN:
		if (m_row < stringList.size() - 1) // if there is a row below, go down
		{
			m_row++;
			list_it++;
			m_col = min(list_it->size(), m_col);
			// ^ column is either the end of the string or the current column
		}
		break;
	case UP:
		if (m_row > 0)		// if there is a row above, go up
		{
			m_row--;
			list_it--;
			m_col = min(list_it->size(), m_col);
			// ^ column is either the end of the string or the current column
		}
		break;
	case HOME:
		m_col = 0;	// go to front of line
		break;
	case END:
		m_col = list_it->size();  // go to end of line
		break;
	}
}

// Helper function for del()
int StudentTextEditor::delHelper(char& ch)
{
	if (m_col != list_it->size())	// no special conditions; just delete the char at m_col
	{
		ch = list_it->at(m_col);
		list_it->erase(m_col, 1);
		return 1;
	}
	if (m_row == stringList.size() - 1)	// delete does nothing on the last row
		return -1;
	list<string>::iterator it = list_it;
	string next_row = *(++it);	// this is the string in the following row
	stringList.erase(it);	// delete the line below
	list_it->append(next_row);	// add that string to the current line
	return 2;
}

// Time Complexity: O(L) normally, O(L1 + L2) for merge
void StudentTextEditor::del()
{
	char ch;
	int res = delHelper(ch);
	if (res == 1)	// no special conditions; just delete the char at m_col
	{
		getUndo()->submit(Undo::Action::DELETE, m_row, m_col, ch);
		return;
	}
	if (res == -1)	// delete does nothing on the last row
		return;
	if (res == 2)
		getUndo()->submit(Undo::Action::JOIN, m_row, m_col, ' ');
}

// Time Complexity: O(L) normally, O(L1 + L2) for merge
void StudentTextEditor::backspace()
{
	if (m_col > 0)
	{
		m_col--;	// backspace does the same thing as del() just one column over
		del();
	}
	else if (m_col == 0 && m_row > 0)
	{
		m_row--;
		list_it--;
		m_col = list_it->size();
		del(); // in this case, we move up to the row above and then call del()
	}
}

// Time Complexity: O(L)
void StudentTextEditor::insert(char ch)
{
	if (ch == 0)
		return;
	if (ch == '\t')		// tab character is 4 spaces
	{
		for (int i = 0; i < 4; i++)
		{
			list_it->insert(m_col, " ");
			m_col++;
			getUndo()->submit(Undo::Action::INSERT, m_row, m_col, ch);
		}
		return;
	}
	string s = "";
	s += ch;
	list_it->insert(m_col, s);	// otherwise, just add the character and increment the column
	m_col++;
	getUndo()->submit(Undo::Action::INSERT, m_row, m_col, ch); // add it to the undo stack
}

// Helper function for enter()
void StudentTextEditor::enterHelper()
{
	int numChars = list_it->size() - m_col;	// the number of chars in the rest of the string
	string rest;
	if (numChars == 0)
		rest = "";
	else
		rest = list_it->substr(m_col, numChars);
	if (rest != "")		// nothing to erase if rest is the empty string
		list_it->erase(m_col, rest.size());
	m_row++;
	if (m_row >= stringList.size())		// need to add a new row at the end
	{
		stringList.push_back(rest);
		list_it++;
	}
	else         // otherwise, add the rest of the string to a new row below
	{
		list_it++;
		list_it = stringList.insert(list_it, rest);
	}
	m_col = 0;
}

// Time Complexity: O(L)
void StudentTextEditor::enter()
{
	getUndo()->submit(Undo::Action::SPLIT, m_row, m_col, ' '); // submit to the undo stack
	enterHelper();
}

// Time Complexity: O(1)
void StudentTextEditor::getPos(int& row, int& col) const
{
	row = m_row;
	col = m_col;
}

// Time Complexity: O(oldR + abs(current row number - startRow) + numRows * L)
int StudentTextEditor::getLines(int startRow, int numRows, std::vector<std::string>& lines) const
{
	lines.clear(); 	 // clear data in lines vector 

	int minimum = min(stringList.size(), numRows); // only get the minimum number of lines

	list<string>::const_iterator it = list_it;
	// if position is out of bounds, return false; otherwise, it now points to the node at startRow
	if (!findPos(startRow, it))
		return 0;
	for (int r = startRow; it != stringList.end() && r < minimum + startRow; r++, it++)
	{
		lines.push_back(*it);	 // pushback the string of the current row
	}
	return lines.size();
}

// Helper function that changes itr to point to the node at position pos 
// Time Complexity: O(abs(current row number - startRow))
bool StudentTextEditor::findPos(int pos, list<string>::const_iterator& itr) const
{
	list<string>::const_iterator it = itr;
	int i = m_row;
	if (pos == 0)	
	{
		itr = stringList.begin();
		return true;
	}
	if (i < pos)	// iterate down through the string list
	{
		// loop through list to get to pos
		int nRows = stringList.size();
		for (; i != pos && i < nRows && it != stringList.end(); i++, it++)
		{
		}
		if (i == nRows || it == stringList.end())	// invalid pos
			return false;
		itr = it;	// itr now points where it should
		return true;
	}
	else            // iterate backwards
	{
		for (; i != pos && i > 0 && it != stringList.begin(); i--, it--)
		{
		}
		if (i == 0)
			return false;
		itr = it;
		return true;
	}
}

// Helper function to readjust the list iterator and m_row to a new row
// Time Complexity: O(abs(newRow - m_row))
void StudentTextEditor::readjustListIteratorAndRow(int newRow)
{
	if (newRow >= m_row)
	{
		while (m_row != newRow)
		{
			list_it++;
			m_row++;
		}
	}
	else          // newRow < m_row
	{
		while (m_row != newRow)
		{
			list_it--;
			m_row--;
		}
	}
}

// This should be meeting the Time Complexity requirements
void StudentTextEditor::undo()
{
	int count = 0;
	string text;
	char c;
	int newRow = m_row;
	switch (getUndo()->get(newRow, m_col, count, text))
	{
	case Undo::Action::DELETE:
		readjustListIteratorAndRow(newRow);	// m_row and list_it need to be readjusted
		list_it->erase(m_col, count);
		break;
	case Undo::Action::INSERT:
		readjustListIteratorAndRow(newRow);
		list_it->insert(m_col, text);
		break;
	case Undo::Action::JOIN:
		readjustListIteratorAndRow(newRow);
		delHelper(c);
		break;
	case Undo::Action::SPLIT:
		readjustListIteratorAndRow(newRow);
		enterHelper();
		break;
	case Undo::Action::ERROR:
		return;
	}
}
